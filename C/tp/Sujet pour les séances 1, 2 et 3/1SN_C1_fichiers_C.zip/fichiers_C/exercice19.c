
#include <stdlib.h> 
#include <stdio.h>

int main(int argc, char* argv[]){
    printf("Les arguments sont : \n");
    // Afficher ici les argc arguments
    
    return EXIT_SUCCESS;
}

